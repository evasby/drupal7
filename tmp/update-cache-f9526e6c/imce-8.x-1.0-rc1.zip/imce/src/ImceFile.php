<?php

/**
 * @file
 * Contains \Drupal\imce\ImceFile.
 */

namespace Drupal\imce;

/**
 * Imce File.
 */
class ImceFile extends ImceItem {

  /**
   * {@inheritdoc}
   */
  public $type = 'file';
}