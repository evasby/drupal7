<?php

$base = array(
  0x00 => NULL, 'N', 'N', 'H', NULL, 'a', 'aa', 'i', 'ii', 'u', 'uu', 'R', 'L', NULL, NULL, 'e',
  0x10 => 'ai', NULL, NULL, 'o', 'au', 'k', 'kh', 'g', 'gh', 'ng', 'c', 'ch', 'j', 'jh', 'ny', 'tt',
  0x20 => 'tth', 'dd', 'ddh', 'nn', 't', 'th', 'd', 'dh', 'n', NULL, 'p', 'ph', 'b', 'bh', 'm', 'y',
  0x30 => 'r', NULL, 'l', 'll', NULL, '', 'sh', 'ss', 's', 'h', NULL, NULL, '\'', '\'', 'aa', 'i',
  0x40 => 'ii', 'u', 'uu', 'R', NULL, NULL, NULL, 'e', 'ai', NULL, NULL, 'o', 'au', '', NULL, NULL,
  0x50 => NULL, NULL, NULL, NULL, NULL, NULL, '+', '+', NULL, NULL, NULL, NULL, 'rr', 'rh', NULL, 'yy',
  0x60 => 'RR', 'LL', NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0x70 => '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0x80 => NULL, NULL, 'N', 'H', NULL, 'a', 'aa', 'i', 'ii', 'u', 'uu', NULL, NULL, NULL, 'e', 'ee',
  0x90 => 'ai', NULL, 'o', 'oo', 'au', 'k', NULL, NULL, NULL, 'ng', 'c', NULL, 'j', NULL, 'ny', 'tt',
  0xA0 => NULL, NULL, NULL, 'nn', 't', NULL, NULL, NULL, 'n', 'nnn', 'p', NULL, NULL, NULL, 'm', 'y',
  0xB0 => 'r', 'rr', 'l', 'll', 'lll', 'v', NULL, 'ss', 's', 'h', NULL, NULL, NULL, NULL, 'aa', 'i',
  0xC0 => 'ii', 'u', 'uu', NULL, NULL, NULL, 'e', 'ee', 'ai', NULL, 'o', 'oo', 'au', '', NULL, NULL,
  0xD0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, '+', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xE0 => NULL, NULL, NULL, NULL, NULL, NULL, '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
  0xF0 => '+10+', '+100+', '+1000+', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
);
